import random

class LoadBalancer:
    def __init__(self, servers):
        self.servers = servers
        self.index = 0   # for round robin

    # Round Robin Algorithm
    def round_robin(self):
        server = self.servers[self.index]
        self.index = (self.index + 1) % len(self.servers)
        return server

    # Random Selection Algorithm
    def random_selection(self):
        return random.choice(self.servers)

    # Hash-Based Load Balancing
    def hash_based(self, request_id):
        return self.servers[request_id % len(self.servers)]


# Simulate Client Requests
def simulate_requests(lb, num_requests):
    for i in range(1, num_requests + 1):
        print("\nRequest", i)

        # Round Robin
        rr_server = lb.round_robin()
        print("Round Robin ->", rr_server)

        # Random
        rand_server = lb.random_selection()
        print("Random ->", rand_server)

        # Hash-based
        hash_server = lb.hash_based(i)
        print("Hash-Based ->", hash_server)


# Main Program
if __name__ == "__main__":
    servers = ["Server A", "Server B", "Server C"]

    lb = LoadBalancer(servers)

    simulate_requests(lb, 10)