import random

# Fitness function (minimize)
def fitness(ind):
    return sum(x**2 for x in ind)

# Create individual
def create_ind():
    return [random.uniform(-5, 5) for _ in range(3)]

# Crossover
def crossover(p1, p2):
    return [(x+y)/2 for x, y in zip(p1, p2)]

# Mutation
def mutate(ind):
    return [x + random.uniform(-1,1) if random.random()<0.2 else x for x in ind]

# Selection (tournament)
def select(pop):
    a, b = random.sample(pop, 2)
    return a if fitness(a) < fitness(b) else b

# Initialize population
pop = [create_ind() for _ in range(50)]

# GA loop
for _ in range(20):
    new_pop = []
    for _ in range(len(pop)):
        p1, p2 = select(pop), select(pop)
        child = crossover(p1, p2)
        child = mutate(child)
        new_pop.append(child)
    pop = sorted(new_pop, key=fitness)

# Best solution
best = pop[0]
print("Best Individual:", best)
print("Best Fitness:", fitness(best))
