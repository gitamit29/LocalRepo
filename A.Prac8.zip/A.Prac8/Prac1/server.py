from xmlrpc.server import SimpleXMLRPCServer
from xmlrpc.server import SimpleXMLRPCRequestHandler

# Restrict to specific path
class RequestHandler(SimpleXMLRPCRequestHandler):
    rpc_paths = ('/RPC2',)

# Server class
class FactorialServer:
    def calculate_factorial(self, n):
        if n < 0:
            return "Error: Enter non-negative number"
        result = 1
        for i in range(1, n + 1):
            result *= i
        return result

# Create server
with SimpleXMLRPCServer(("localhost", 8000),
                        requestHandler=RequestHandler) as server:
    
    server.register_introspection_functions()
    server.register_instance(FactorialServer())

    print("✅ Factorial Server is running on port 8000...")
    
    server.serve_forever()