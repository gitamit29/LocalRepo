import Pyro4

@Pyro4.expose
class StringConcatenationServer:
    def concatenate_strings(self, str1, str2):
        return str1 + str2

def main():
    # Start Pyro daemon
    daemon = Pyro4.Daemon()

    # Locate Name Server
    ns = Pyro4.locateNS()

    # Create server object
    server = StringConcatenationServer()

    # Register object with daemon
    uri = daemon.register(server)

    # Register name with Name Server
    ns.register("string.concatenation", uri)

    print("✅ Server is running...")
    print("URI:", uri)

    # Save URI to file (for client use)
    with open("server_uri.txt", "w") as f:
        f.write(str(uri))

    # Start listening
    daemon.requestLoop()

if __name__ == "__main__":
    main()