import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

from sklearn.datasets import load_iris

# Load Dataset
data = load_iris()

# Create DataFrame
df = pd.DataFrame(data=data.data, columns=data.feature_names)

print(df.head())
print(df.info())

X = data.data
Y = data.target

# Split Dataset
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

X_train, X_test, Y_train, Y_test = train_test_split(
    X, Y, test_size=0.2, random_state=0
)

# Feature Scaling
sc_X = StandardScaler()

X_train = sc_X.fit_transform(X_train)
X_test = sc_X.transform(X_test)

print(f'Train Dataset Size - X: {X_train.shape}, Y: {Y_train.shape}')
print(f'Test Dataset Size - X: {X_test.shape}, Y: {Y_test.shape}')

# Naive Bayes Classifier
from sklearn.naive_bayes import GaussianNB

classifier = GaussianNB()

classifier.fit(X_train, Y_train)

predictions = classifier.predict(X_test)

# Plot Graphs
fig, axs = plt.subplots(2, 2, figsize=(12, 10), constrained_layout=True)

fig.suptitle('Regression Line Tracing')

for i in range(4):

    x = i // 2
    y = i % 2

    sns.regplot(
        x=X_test[:, i],
        y=predictions,
        ax=axs[x, y]
    )

    axs[x, y].scatter(
        X_test[:, i][::-1],
        Y_test[::-1],
        marker='+',
        color="white"
    )

    axs[x, y].set_xlabel(df.columns[i])

plt.show()

# Confusion Matrix
from sklearn.metrics import confusion_matrix
from sklearn.metrics import classification_report

cm = confusion_matrix(Y_test, predictions)

print(f'''
Confusion matrix :

                | Positive Prediction | Negative Prediction
--------------- + ------------------- + -------------------
Positive Class  | True Positive (TP) {cm[0,0]} | False Negative (FN) {cm[0,1]}
--------------- + ------------------- + -------------------
Negative Class  | False Positive (FP) {cm[1,0]} | True Negative (TN) {cm[1,1]}
''')

# Classification Report
report = classification_report(Y_test, predictions)

print('Classification report : \n', report)