import Pyro4

def main():
    try:
        # Read server URI
        with open("server_uri.txt", "r") as f:
            uri = f.read().strip()

        # Connect to server
        server = Pyro4.Proxy(uri)

        # Take input
        str1 = input("Enter first string: ")
        str2 = input("Enter second string: ")

        # Call remote method
        result = server.concatenate_strings(str1, str2)

        print("✅ Concatenated Result:", result)

    except Exception as e:
        print("❌ Error:", e)

if __name__ == "__main__":
    main()