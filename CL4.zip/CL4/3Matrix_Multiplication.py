from collections import defaultdict

# Mapper
def mapper(matrix_name, row, col, value, n):
    outputs = []
    
    if matrix_name == "A":
        for k in range(n):
            key = (row, k)
            outputs.append((key, ("A", col, value)))
    
    elif matrix_name == "B":
        for i in range(n):
            key = (i, col)
            outputs.append((key, ("B", row, value)))
    
    return outputs


# Reducer
def reducer(key, values):
    A_dict = {}
    B_dict = {}
    
    for val in values:
        matrix_name, index, value = val
        if matrix_name == "A":
            A_dict[index] = value
        else:
            B_dict[index] = value
    
    total = 0
    for j in A_dict:
        if j in B_dict:
            total += A_dict[j] * B_dict[j]
    
    return (key, total)


# Driver
def main():
    n = 2  # dimension (2x2 matrices)
    
    # Matrix A
    A = [
        (0, 0, 1),
        (0, 1, 2),
        (1, 0, 3),
        (1, 1, 4)
    ]
    
    # Matrix B
    B = [
        (0, 0, 5),
        (0, 1, 6),
        (1, 0, 7),
        (1, 1, 8)
    ]
    
    mapped = []
    
    # Map phase
    for row, col, val in A:
        mapped.extend(mapper("A", row, col, val, n))
    
    for row, col, val in B:
        mapped.extend(mapper("B", row, col, val, n))
    
    # Shuffle phase
    grouped = defaultdict(list)
    for key, value in mapped:
        grouped[key].append(value)
    
    # Reduce phase
    results = []
    for key in grouped:
        results.append(reducer(key, grouped[key]))
    
    # Print result matrix
    print("Result Matrix:")
    for key, value in sorted(results):
        print(f"C{key} = {value}")


if __name__ == "__main__":
    main()
