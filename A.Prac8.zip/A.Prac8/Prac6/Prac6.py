import random
import math

# Objective function (example: minimize f(x) = x^2)
def objective_function(x):
    return x ** 2

# Generate initial population
def generate_population(size, lower_bound, upper_bound):
    return [random.uniform(lower_bound, upper_bound) for _ in range(size)]

# Affinity (fitness) calculation (lower is better here)
def affinity(x):
    return 1 / (1 + objective_function(x))

# Clone selected antibodies
def clone(population, clone_factor):
    clones = []
    for i, antibody in enumerate(population):
        num_clones = int(clone_factor / (i + 1))  # better antibodies → more clones
        clones.extend([antibody] * num_clones)
    return clones

# Hypermutation (small random changes)
def mutate(clones, mutation_rate, lower_bound, upper_bound):
    mutated = []
    for c in clones:
        if random.random() < mutation_rate:
            c += random.uniform(-1, 1)
            # Keep within bounds
            c = max(min(c, upper_bound), lower_bound)
        mutated.append(c)
    return mutated

# Select best individuals
def select_best(population, size):
    return sorted(population, key=lambda x: objective_function(x))[:size]

# Main CSA function
def clonal_selection(pop_size=10, generations=20, clone_factor=5,
                     mutation_rate=0.3, lower_bound=-10, upper_bound=10):

    # Step 1: Initialize population
    population = generate_population(pop_size, lower_bound, upper_bound)

    for gen in range(generations):
        # Step 2: Evaluate affinity
        population = sorted(population, key=lambda x: objective_function(x))

        # Step 3: Select best half
        selected = population[:pop_size // 2]

        # Step 4: Clone
        clones = clone(selected, clone_factor)

        # Step 5: Mutate
        mutated_clones = mutate(clones, mutation_rate, lower_bound, upper_bound)

        # Step 6: Select best from clones
        best_clones = select_best(mutated_clones, pop_size // 2)

        # Step 7: Replace worst population
        population = selected + best_clones

        # Print best solution in each generation
        best = min(population, key=lambda x: objective_function(x))
        print(f"Generation {gen+1}: Best = {best:.4f}, f(x) = {objective_function(best):.4f}")

    return best

# Run the algorithm
best_solution = clonal_selection()
print("\nBest Final Solution:", best_solution)
