import numpy as np

# -------------------------------
# Fuzzy Set Operations
# -------------------------------

# Union (max)
def fuzzy_union(A, B):
    return np.maximum(A, B)

# Intersection (min)
def fuzzy_intersection(A, B):
    return np.minimum(A, B)

# Complement (1 - A)
def fuzzy_complement(A):
    return 1 - A

# Difference (A - B) = min(A, 1 - B)
def fuzzy_difference(A, B):
    return np.minimum(A, 1 - B)


# -------------------------------
# Fuzzy Relations
# -------------------------------

# Cartesian Product
def cartesian_product(A, B):
    return np.outer(A, B)


# Max-Min Composition (Correct Version)
def max_min_composition(R, S):
    result = np.zeros((R.shape[0], S.shape[1]))

    for i in range(R.shape[0]):
        for j in range(S.shape[1]):
            result[i][j] = max(
                min(R[i][k], S[k][j]) for k in range(R.shape[1])
            )

    return result


# -------------------------------
# MAIN PROGRAM
# -------------------------------

# Fuzzy Sets
A = np.array([0.2, 0.4, 0.6, 0.8])
B = np.array([0.3, 0.5, 0.7, 0.9])

print("Fuzzy Set A:", A)
print("Fuzzy Set B:", B)

# Operations
print("\n--- Fuzzy Set Operations ---")
print("Union:", fuzzy_union(A, B))
print("Intersection:", fuzzy_intersection(A, B))
print("Complement of A:", fuzzy_complement(A))
print("Difference (A - B):", fuzzy_difference(A, B))


# -------------------------------
# Fuzzy Relations
# -------------------------------

# Create Relations using Cartesian Product
R = cartesian_product(A, B)
S = cartesian_product(B, A)

print("\n--- Fuzzy Relations ---")
print("Relation R (A x B):\n", R)
print("Relation S (B x A):\n", S)

# Max-Min Composition
composition = max_min_composition(R, S)

print("\n--- Max-Min Composition (R o S) ---")
print(composition)