from sklearn.datasets import load_iris
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt

# Load dataset
data = load_iris()

X = data.data[:, :2]

# Create K-Means model
model = KMeans(n_clusters=3, random_state=42)

# Train model
model.fit(X)

# Get cluster labels
labels = model.labels_

# Plot clusters
plt.scatter(X[:, 0], X[:, 1], c=labels)

plt.xlabel("Sepal Length")
plt.ylabel("Sepal Width")

plt.title("K-Means Clustering")

plt.show()