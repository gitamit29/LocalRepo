# Sample data (you can also read from file)
data = [
    "2001,30",
    "2001,32",
    "2002,28",
    "2002,35",
    "2003,25",
    "2003,27"
]

# MAP phase → (year, temperature)
mapped = []
for line in data:
    year, temp = line.split(",")
    mapped.append((year, int(temp)))

# SHUFFLE phase → group by year
shuffle = {}
for year, temp in mapped:
    if year not in shuffle:
        shuffle[year] = []
    shuffle[year].append(temp)

# REDUCE phase → average temp per year
avg_temp = {}
for year, temps in shuffle.items():
    avg_temp[year] = sum(temps) / len(temps)

# Find hottest & coolest year
hottest = max(avg_temp, key=avg_temp.get)
coolest = min(avg_temp, key=avg_temp.get)

print("Average temp per year:", avg_temp)
print("Hottest Year:", hottest)
print("Coolest Year:", coolest)
