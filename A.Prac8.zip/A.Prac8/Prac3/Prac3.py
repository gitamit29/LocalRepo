import random
from deap import base, creator, tools, algorithms

# -------------------------------
# Evaluation Function (Mock)
# -------------------------------
def evaluate(individual):
    return (random.random(),)   # Must return tuple


# -------------------------------
# Genetic Algorithm Parameters
# -------------------------------
POPULATION_SIZE = 10
GENERATIONS = 5


# -------------------------------
# Create Fitness and Individual
# -------------------------------
# ✅ FIXED HERE
if not hasattr(creator, "FitnessMin"):
    creator.create("FitnessMin", base.Fitness, weights=(-1.0,))

if not hasattr(creator, "Individual"):
    creator.create("Individual", list, fitness=creator.FitnessMin)


# -------------------------------
# Initialize Toolbox
# -------------------------------
toolbox = base.Toolbox()

toolbox.register("attr_neurons", random.randint, 1, 100)
toolbox.register("attr_layers", random.randint, 1, 5)

toolbox.register(
    "individual",
    tools.initCycle,
    creator.Individual,
    (toolbox.attr_neurons, toolbox.attr_layers),
    n=1
)

toolbox.register("population", tools.initRepeat, list, toolbox.individual)


# -------------------------------
# Genetic Operators
# -------------------------------
toolbox.register("evaluate", evaluate)
toolbox.register("mate", tools.cxTwoPoint)
toolbox.register("mutate", tools.mutUniformInt, low=1, up=100, indpb=0.2)
toolbox.register("select", tools.selTournament, tournsize=3)


# -------------------------------
# Create Initial Population
# -------------------------------
population = toolbox.population(n=POPULATION_SIZE)


# -------------------------------
# Run Genetic Algorithm
# -------------------------------
for gen in range(GENERATIONS):
    print(f"Generation {gen+1}")

    offspring = algorithms.varAnd(population, toolbox, cxpb=0.5, mutpb=0.1)

    fitnesses = list(map(toolbox.evaluate, offspring))

    for ind, fit in zip(offspring, fitnesses):
        ind.fitness.values = fit

    population = toolbox.select(offspring, k=len(population))


# -------------------------------
# Get Best Individual
# -------------------------------
best_individual = tools.selBest(population, k=1)[0]
print("Best Parameters:", best_individual)