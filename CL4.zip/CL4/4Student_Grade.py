from collections import defaultdict

# Mapper
def mapper(line):
    fields = line.strip().split(",")
    student_id = fields[0]
    marks = int(fields[1])
    return (student_id, marks)


# Function to calculate grade
def calculate_grade(total_marks):
    if total_marks >= 90:
        return "A"
    elif total_marks >= 80:
        return "B"
    elif total_marks >= 70:
        return "C"
    elif total_marks >= 60:
        return "D"
    else:
        return "F"


# Reducer
def reducer(student_id, marks_list):
    total_marks = sum(marks_list)
    grade = calculate_grade(total_marks)
    return (student_id, grade)


# Driver Program
def main():

    # Sample input data
    input_data = [
        "101,40",
        "102,50",
        "101,55",
        "103,30",
        "102,45",
        "103,50"
    ]

    # Map Phase
    mapped = []

    for line in input_data:
        mapped.append(mapper(line))

    # Shuffle and Sort Phase
    grouped = defaultdict(list)

    for student_id, marks in mapped:
        grouped[student_id].append(marks)

    # Reduce Phase
    results = []

    for student_id in grouped:
        results.append(reducer(student_id, grouped[student_id]))

    # Final Output
    print("Final Grades:")

    for student_id, grade in sorted(results):
        print(f"Student {student_id} -> Grade {grade}")


if __name__ == "__main__":
    main()